package StepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import com.Qa.factory.DriverFactory;
import com.page.SignInPg;

import io.cucumber.java.en.*;

public class SignInPgSteps {
	
	private SignInPg signInPg=new SignInPg(DriverFactory.getDriver());
	
	@Given("user is on login page")
	public void user_is_on_login_page() {
	   //DriverFactory.getDriver().get("http://www.automationpractice.pl/index.php?controller=authentication&back=my-account");
	   DriverFactory.getDriver().get("http://www.automationpractice.pl/index.php?controller=authentication&back=my-account");
	}

	@When("user enters username {string}")
	public void user_enters_username(String username) {
		 System.out.println("Inside Entering the username ");
		 signInPg.enterUserName(username);
	}

	@And("user enters password {string}")
	public void user_enters_password(String password) {
		 System.out.println("Inside Entering the password");
		 signInPg.enterPassword(password);
	}

	@And("user clicks on Login button")
	public void user_clicks_on_login_button() {
		System.out.println("clicking the login button");
		signInPg.clickOnLogin();
	   
	}
}
